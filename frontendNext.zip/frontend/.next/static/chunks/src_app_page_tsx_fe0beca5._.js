(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@sanity_560ee390._.js",
  "static/chunks/src_914a7759._.js",
  "static/chunks/node_modules_framer-motion_dist_es_a224e917._.js",
  "static/chunks/node_modules_motion-dom_dist_es_fa3ea29e._.js",
  "static/chunks/node_modules_rxjs_dist_esm5_internal_c13e6c75._.js",
  "static/chunks/node_modules_@sanity_client_dist_9feee8e8._.js",
  "static/chunks/node_modules_cd6abfc8._.js"
],
    source: "dynamic"
});
